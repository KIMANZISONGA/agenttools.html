export default async (request, context) => {
  const auth = request.headers.get("authorization");

  const username = "stephen";
  const password = "kimanzi-agents-only";
  const expected = "Basic " + btoa(`${username}:${password}`);

  if (auth !== expected) {
    return new Response("Authentication required", {
      status: 401,
      headers: {
        "WWW-Authenticate": 'Basic realm="Kimanzi Agent Tools"'
      }
    });
  }

  return context.next();
};